package orderStatistics;

public class MainProgarm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		KthSmallest ob=new KthSmallest();
		int arr[]= {12, 3, 5, 9, 6, 19, 26};
		int left=0;
		int n=arr.length;
		int right=n-1;
		int k=5;
		System.out.println("K'th smallest element is "+ ob.kthSmallst(arr, left, right, k));

	}

}
