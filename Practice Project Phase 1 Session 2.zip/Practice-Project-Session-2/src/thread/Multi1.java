package thread;

public class Multi1 implements Runnable{
	
	public void run() {
             
		for(int i=1; i<6; i++) {
			
		System.out.println(i+ " "+Thread.currentThread().getName());
		
			 try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}//1000milliseconds=1second
			
		}
		System.out.println("Thread is running.....");
	}
	
	public static void main(String[] args) {
		Multi1 t1=new Multi1();
		Multi1 t2=new Multi1();
		
		Thread m1=new Thread(t1);
		Thread m2=new Thread(t2);
		
		m1.setName("First");
		m2.setName("Second");
		
		m1.start();
		m2.start();

	}

}
