package exceptionhandling;

public class MyException extends Exception{
	
	String s1;
	MyException(String s2) {
		s1=s2;
	}
	@Override
	public String toString() {
		return "MyException occurs : "+s1;
	}
	
	
	

}
