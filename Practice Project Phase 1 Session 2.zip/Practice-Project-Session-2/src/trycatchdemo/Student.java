package trycatchdemo;

public class Student {
	public static void main(String[] args) {
		
		try {
			
			int data=40/0;
		} 
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println("Error :"+e);
		}
		System.out.println("Rest of the code");
	}

}
