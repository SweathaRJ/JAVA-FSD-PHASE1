package diamond;

public class Test implements first,second {
	
	   
		@Override
	public void display() {
		// TODO Auto-generated method stub
		first.super.display();
		second.super.display();
	}

		public static void main(String args[]) 
	    { 
	        Test ob = new Test(); 
	        ob.display(); 
	    } 


	
}
