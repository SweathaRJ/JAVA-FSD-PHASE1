package diamond;

public interface second {
	
	default void display() {
		
		System.out.println("Method of second interface invoked");
		
	}

}
