package diamond;

public interface first {
	
	default void display() {
		
		System.out.println("Method of first interface invoked");
	}

}
