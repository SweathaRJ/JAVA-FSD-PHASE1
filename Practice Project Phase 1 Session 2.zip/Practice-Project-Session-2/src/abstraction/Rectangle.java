package abstraction;

public class Rectangle extends Shape {
	
	private double length;
	private double breadth;
	
	public Rectangle(String color, double length, double breadth) {
		super(color);
		this.length = length;
		this.breadth = breadth;
	}

	@Override
	double area() {
		// TODO Auto-generated method stub
		return length * breadth;
	}

	@Override
	public String toString() {
		return "Rectangle color = " +getColor()+ " and area is :"+area();
	}
	
	
	
	
	
	
	
	
	

}
