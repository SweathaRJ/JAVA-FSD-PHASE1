package abstraction;

public class Test {

	public static void main(String[] args) {
		
		Shape s1= new Circle("Orange", 5);
		Shape s2=new Rectangle("Pink", 6, 8);
		
		System.out.println(s1);
		System.out.println(s2);
		
	}
}
