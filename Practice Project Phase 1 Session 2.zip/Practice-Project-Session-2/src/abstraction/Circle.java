package abstraction;

public class Circle extends Shape {
	
	private double radius;

	public Circle(String color, double radius) {
		super(color);
		this.radius = radius;
	}

	@Override
	double area() {
		// TODO Auto-generated method stub
		return Math.PI * Math.pow(radius, 3);
	}

	@Override
	public String toString() {
		return "Circle color = "+getColor()+" and area is : "+area();
	}
	
	
	
	

}
