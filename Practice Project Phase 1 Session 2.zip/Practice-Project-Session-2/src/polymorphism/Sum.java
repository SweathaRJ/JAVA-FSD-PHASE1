package polymorphism;

public class Sum {
	
	public int sum(int a, int b) 
    { 
        return (a + b); 
    } 
    public int sum(int a, int b, int c) 
    { 
        return (a + b + c); 
    } 
    public double sum(double a, double b) 
    { 
        return (a + b); 
    }

    public static void main(String[] args) {
		// TODO Auto-generated method stub
    	Sum s = new Sum(); 
        System.out.println("The sum of two int = " + s.sum(5, 9)); 
        System.out.println("The sum of three int = " + s.sum(1, 4, 3)); 
        System.out.println("The sum of two double = " + s.sum(17.9, 34.5)); 
    }

}
