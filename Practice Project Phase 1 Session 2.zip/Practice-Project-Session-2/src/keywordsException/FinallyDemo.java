package keywordsException;

public class FinallyDemo {

	public static void main(String[] args) {
		int a=10,b=0,c=0;
		try {
			
			c=a/b;
			
		} catch (ArithmeticException e) {
			System.out.println("Error:"+e.getMessage());
		}
		finally {
			System.out.println("The result is : ");
		}

	}

}
