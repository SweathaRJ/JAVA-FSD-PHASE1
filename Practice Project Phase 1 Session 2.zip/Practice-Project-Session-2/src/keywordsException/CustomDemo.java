package keywordsException;

public class CustomDemo {
	
	static void check (int age) throws AgeNotValidException{
		if(age<18)
			throw new AgeNotValidException("Candidate cannot vote before 18");
		else
			System.out.println("Candidate can vote");
	}
	
	public static void main(String[] args) {
		
		try {
			
			check(19);
		} 
		catch (AgeNotValidException e) {
			// TODO: handle exception
			System.out.println("Error:"+e);
		}
		
		
	}

}
