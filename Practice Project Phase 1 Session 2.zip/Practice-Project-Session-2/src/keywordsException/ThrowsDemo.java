package keywordsException;

public class ThrowsDemo {
	
	public static int divideNum(int m,int n) throws ArithmeticException{
		int div=m/n;
		return div;
	}

	public static void main(String[] args) {
		
		ThrowsDemo obj=new ThrowsDemo();
		try {
			
			System.out.println("Number is divided : " + obj.divideNum(35, 7));
			
		} 
		catch (ArithmeticException e) {
			System.out.println("Error:"+e);
			
		}
		

	}

}
