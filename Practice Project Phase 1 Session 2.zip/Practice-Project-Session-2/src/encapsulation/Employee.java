package encapsulation;

public class Employee {
	
	private String name;
	private String company;
	private String emailId;
	private String access;
	private int id;
	private String designation;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
}
	@Override
	public String toString() {
		return "name=" + name + "\ncompany=" + company + "\nemailId=" + emailId + "\naccess=" + access
				+ "\nid=" + id + "\ndesignation=" + designation;
	}
}
