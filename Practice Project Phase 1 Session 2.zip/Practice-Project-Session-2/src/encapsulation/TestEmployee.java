package encapsulation;

public class TestEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee();
		e1.setName("Sweatha");
		e1.setCompany("XYZ");
		e1.setEmailId("sweatha.rj@gmail.com");
		e1.setAccess("Smiley@1701");
		e1.setId(5);
		e1.setDesignation("Assisstant");
		
		System.out.println(e1);

	}

}
