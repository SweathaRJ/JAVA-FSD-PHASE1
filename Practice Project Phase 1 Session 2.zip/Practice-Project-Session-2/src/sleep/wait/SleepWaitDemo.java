package sleep.wait;

public class SleepWaitDemo {
	
	private static Object obj=new Object();

	public static void main(String[] args) {
		
		try {
			Thread.sleep(2000);
			System.out.println(Thread.currentThread().getName()+"Thread will woken after two seconds");
		
		synchronized (obj) {
			
			obj.wait(2000);
			System.out.println("Object is in wait and woke up after two seconds ");
			
		    }
		}
		catch (InterruptedException e) {
			
			e.printStackTrace();
			System.out.println("Error occured: "+e);
			
		}

	}

}
