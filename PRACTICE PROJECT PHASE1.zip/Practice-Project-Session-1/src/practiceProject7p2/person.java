package practiceProject7p2;

public abstract class person {
	
	abstract void eat();

}
